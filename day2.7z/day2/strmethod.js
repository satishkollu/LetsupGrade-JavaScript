var fruits = ["Banana", "Orange", "Apple", "Mango"];


document.getElementById("demo");


fruits.pop();


fruits.push("Kiwi");  


fruits.shift();


fruits.unshift("Lemon");


fruits.unshift("Lemon");


fruits[0] = "Kiwi"; 


delete fruits[0];


fruits.splice(2, 0, "Lemon", "Kiwi");


fruits.splice(2, 2, "Lemon", "Kiwi");

var myGirls = ["Cecilie", "Lone"];
var myBoys = ["Emil", "Tobias", "Linus"];
var myChildren = myGirls.concat(myBoys);

var arr1 = ["Cecilie", "Lone"];
var arr2 = ["Emil", "Tobias", "Linus"];
var arr3 = ["Robin", "Morgan"];
var myChildren = arr1.concat(arr2, arr3);